import React from 'react';
import Draggable from 'react-draggable';
import './App.css';

class App extends React.Component {
 
  render() {
    const dragHandlers = {onStart: this.onStart, onStop: this.onStop};
    return (
      <div>
        <h1 class="mt-5">React Draggable</h1><br></br>
      
        <Draggable {...dragHandlers}>
          <div className="box">I can be dragged anywhere</div>
        </Draggable>

        <Draggable axis="x" {...dragHandlers}>
          <div className="box cursor-x">I can only be dragged horizonally (x axis)</div>
        </Draggable>

        <Draggable handle="strong">
          <div className="box no-cursor" style={{display: 'flex', flexDirection: 'column'}}>
            <strong className="cursor"><div><b>Drag here</b></div></strong>
            <div style={{overflow: 'scroll'}}>
              <div style={{background: 'yellow', whiteSpace: 'pre-wrap'}}>
                I have long scrollable content with a handle
                {'\n' + Array(40).fill('x').join('\n')}
              </div>
            </div>
          </div>
        </Draggable>

        <Draggable cancel="strong" {...dragHandlers}>
          <div className="box">
            <strong className="no-cursor"><b>Can't drag here</b></strong>
            <div>Dragging here works</div>
          </div>
        </Draggable>

      </div>
    );
  }
}

export default App;
