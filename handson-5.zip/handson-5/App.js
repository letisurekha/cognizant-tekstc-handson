import React from 'react';
import FormCode from './FormCode';
class App extends React.Component {
  submit = (values) => {
    alert("submitted");
    console.log(values);
  }
  render() {
    return (
      <div className="container">
        <br></br>
        <h1>Form Validation <span style={{ color: "red" }}>*</span></h1>
        <FormCode onSubmit={this.submit} />
      </div>
    )
  }
}
export default App;

